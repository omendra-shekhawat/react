in this duration i have cover chapter 4 which contain Fragments, pure component , memo, refs, refs with class component, error boundary.

then i start work on task 3.