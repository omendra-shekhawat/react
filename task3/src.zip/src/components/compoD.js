import React, { Component } from 'react'

class ComponentD extends Component {
    render() {
        return (
            <div>
                <span>Helo Component D</span>
            </div>
        )
    }
}

export default ComponentD